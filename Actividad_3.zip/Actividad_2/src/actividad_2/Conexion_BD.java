/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad_2;

import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author manri
 */
public class Conexion_BD {
    
    public Connection getConnection()
    {
        Connection Con = null;
        String base = "cajerobd";
        String url = "jdbc:mysql://localhost:3306/"+ base;
        String user = "root";
        String password = "";
        
        try 
        {
            Class.forName("com.mysql.jdbc.Driver");
            Con = (Connection) DriverManager.getConnection(url, user, password);
        } 
        catch (Exception e)
        {
            System.err.print (e);
        }
        
        return Con;
    }
}
